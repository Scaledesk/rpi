	<footer>
	<div class="container">
		<div class="row">
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Contact Us</h5>
					<address>
					<strong>RPI - India</strong><br>
					<p> 301, 3rd floor, 5 Pusa Road, New Delhi<br>
						Contact Person: James Washington <br> 
						 
						
						</p>


					 </address>
					<p>
						<i class="icon-phone"></i>Contact number: 9811926888 <br>
						<i class="icon-envelope-alt"></i> Contact Email Id: jamesrpi@respac.com
					</p>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Quick Links</h5>
					<ul class="link-list">
					 
			            <li class="active"><a href="<?php echo base_url();?>">Home</a></li> 
						<li><a href="<?php echo base_url().'users/aboutShow';?>">About Us</a></li>
						<li><a href="<?php echo base_url().'users/servicesShow';?>">Services</a></li>
                        <li><a href="<?php echo base_url().'users/researchShow';?>">Research</a></li>
                        <li><a href="<?php echo base_url().'users/strengthShow';?>">Strength</a></li>
                        <li><a href="<?php echo base_url().'users/contactUsShow';?>">Contact</a></li>
						<!-- <li><a href="#">Latest Events</a></li>
						<li><a href="#">Terms and conditions</a></li>
						<li><a href="#">Privacy policy</a></li>
						<li><a href="#">Career</a></li>
						<li><a href="#">Contact us</a></li> -->
					</ul>
				</div>
			</div>

			<!-- <div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Latest posts</h5>
					<ul class="link-list">
						<li><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></li>
						<li><a href="#">Pellentesque et pulvinar enim. Quisque at tempor ligula</a></li>
						<li><a href="#">Natus error sit voluptatem accusantium doloremque</a></li>
					</ul>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="widget">
					<h5 class="widgetheading">Recent News</h5>
					<ul class="link-list">
						<li><a href="#">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</a></li>
						<li><a href="#">Pellentesque et pulvinar enim. Quisque at tempor ligula</a></li>
						<li><a href="#">Natus error sit voluptatem accusantium doloremque</a></li>
					</ul>
				</div>
			</div> -->
		</div>
	</div>
	<div id="sub-footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>
							<span>&copy; The Rsearch Pacific Group 2015 All right reserved. Designed and Maintined By </span><a href="http://www.weboservices.com" target="_blank">Webo Services</a>
						</p>
					</div>
				</div>
				<div class="col-lg-6">
					<ul class="social-network">
						<li><a href="#" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#" data-placement="top" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
						<li><a href="#" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
						<li><a href="#" data-placement="top" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo base_url();?>assets\assets\js\jquery.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\jquery.easing.1.3.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\jquery.fancybox.pack.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\jquery.fancybox-media.js"></script> 
<script src="<?php echo base_url();?>assets\assets\js\portfolio\jquery.quicksand.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\portfolio\setting.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\jquery.flexslider.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\animate.js"></script>
<script src="<?php echo base_url();?>assets\assets\js\custom.js"></script>
<script src="<?php echo base_url();?>assets\assets\js/owl-carousel/owl.carousel.js"></script>
</body>
</html>