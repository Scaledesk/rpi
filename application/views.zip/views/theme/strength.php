<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<h2 class="pageTitle">Strength</h2>
			</div>
		</div>
	</div>
	</section>
<?php /*echo "<pre/>"; print_r($research);*/?>







<section id="content">
	<div class="container">
					
					<div class="about">
					
						<div class="row"> 
							<div class="col-md-12">
								<div class="about-logo">
								<?php foreach ($strength as  $row) {
									
								 ?>
								  <?php echo $row['rpi_strength_name']; ?>
									<hr>
								 <?php } ?>
								</div>
								
							</div>
						</div>
						
						
						<br>
						
		 						
						
						
					</div>
									
				</div>
	</section>